import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM
import numpy as np
import os

# 1. Load Data
def load_data(file_path):
    print("Loading transaction data...")
    df = pd.read_csv(file_path)
    return df

# 2. Preprocess Data
def preprocess_data(df):
    print("Cleaning and preparing data...")
    df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce').fillna(0)
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df.dropna(inplace=True)
    df = df.sort_values('Date') # Ensure data is in chronological order
    return df

# 3. Build and Train the Neural Network
def train_model(df):
    print("Preparing Neural Network Engine...")
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_amounts = scaler.fit_transform(df['Amount'].values.reshape(-1, 1))
    
    # Create sequences for the LSTM model
    X, y = [], []
    for i in range(len(scaled_amounts) - 1):
        X.append(scaled_amounts[i])
        y.append(scaled_amounts[i+1])
    X, y = np.array(X), np.array(y)
    X = np.reshape(X, (X.shape[0], 1, X.shape[1]))
    
    print("Building LSTM Model...")
    model = Sequential()
    model.add(LSTM(50, activation='relu', input_shape=(1, 1)))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    
    print("Training Model (this might take a moment)...")
    model.fit(X, y, epochs=10, batch_size=32, verbose=1)
    return model, scaler, X, y

# 4. Detect Anomalies and Visualize
def detect_and_visualize(model, scaler, X, y):
    print("Detecting hidden Salami Attacks...")
    predictions = model.predict(X)
    
    # Convert predictions back to real currency amounts
    predictions = scaler.inverse_transform(predictions)
    actuals = scaler.inverse_transform(y.reshape(-1, 1))
    
    # Generate the graph
    plt.figure(figsize=(12, 6))
    plt.plot(actuals, label='Actual Transactions', color='blue')
    plt.plot(predictions, label='Predicted/Expected Normal', color='orange', alpha=0.7)
    plt.title('Salami Attack Detection: Neural Network Analysis')
    plt.xlabel('Time Steps')
    plt.ylabel('Transaction Amount ($)')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    # Point the code to the data folder we created
    data_path = 'data/transactions.csv'
    
    if not os.path.exists(data_path):
        print(f"Error: Could not find {data_path}. Please check your folder structure.")
    else:
        # Execute the pipeline
        df = load_data(data_path)
        df = preprocess_data(df)
        model, scaler, X, y = train_model(df)
        detect_and_visualize(model, scaler, X, y)
